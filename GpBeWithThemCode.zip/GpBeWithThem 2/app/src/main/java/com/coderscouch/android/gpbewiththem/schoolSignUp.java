package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class schoolSignUp extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mDatabase;
    FirebaseUser user;
    EditText schoolName , schoolID, schoolPass,schoolConfirmPass,schoolNumber,supervFName,supervSName,supervThName,schoolEmail;
    String SschoolName , SschoolID, SschoolPass,SschoolConfirmPass,SschoolNumber,SsupervFName,SsupervSName,SsupervThName,SschoolEmail;
    int intSchoolNum;
    Button signUpSchool ;
    private Button backButton;
    String specialCharRegex= ".*[@#!$%^&+=].*";
    String UpperCaseRegex= ".*[A-Z].*";
    String NumberRegex= ".*[0-9].*";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_sign_up);
//declaring firebase variables and assigning the database to them
        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        //assigning the variables to the variables in xml file
        schoolName= (EditText)findViewById(R.id.schoolNameEditText);
        schoolID = (EditText)findViewById(R.id.schoolID);
        schoolPass =(EditText)findViewById(R.id.schoolPass);
        schoolConfirmPass = (EditText)findViewById(R.id.schoolPassConfirm);
        schoolNumber = (EditText)findViewById(R.id.schoolNumber);
        supervFName = (EditText)findViewById(R.id.supervisorFName);
        supervSName = (EditText)findViewById(R.id.supervisorSName);
        supervThName =(EditText)findViewById(R.id.supervisorThName);
        schoolEmail = (EditText)findViewById(R.id.schoolEmail);
        signUpSchool = (Button) findViewById(R.id.schoolSignUpButton);
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(schoolSignUp.this, MainActivity.class);
                startActivity(myIntent);
            }
        });
        signUpSchool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //calling the method for retrieving data from xml file
                getText();
                //calling the method for data validation
                if(checkTexts()) {
                    //if all data is valid then register the new user
                    registerNewUser();
                }
            }
        });
    }
    private void registerNewUser() {
        //register new user using email and password method
        firebaseAuth.createUserWithEmailAndPassword(SschoolEmail, SschoolPass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    //checking if register is completed
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //if email and password are successfully registered then call the method that enters the rest of the data to the database

                            enterSchoolData();
                            Toast.makeText(getApplicationContext(), "تم التسجيل بنجاح", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(schoolSignUp.this, MainActivity.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "لا يمكنك التسجيل البريد الالكترواني موجود", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(schoolSignUp.this, schoolSignUp.class);
                            startActivity(intent);
                        }
                    }
                });
    }


    void getText(){
        SschoolName = schoolName.getText().toString();
        SschoolID = schoolID.getText().toString();
        SschoolPass =schoolPass.getText().toString();
        SschoolConfirmPass =schoolConfirmPass.getText().toString();
        SschoolNumber = schoolNumber.getText().toString();
        SsupervFName=supervFName.getText().toString();
        SsupervSName=supervSName.getText().toString();
        SsupervThName=supervThName.getText().toString();
        SschoolEmail=schoolEmail.getText().toString();

    }
   public Boolean checkTexts(){
        //data validation
       if (TextUtils.isEmpty(SschoolEmail)||TextUtils.isEmpty(SschoolName)||TextUtils.isEmpty(SschoolPass)||TextUtils.isEmpty(SschoolID)||TextUtils.isEmpty(SschoolNumber)||TextUtils.isEmpty(SsupervFName)||TextUtils.isEmpty(SsupervSName)||TextUtils.isEmpty(SsupervThName)||TextUtils.isEmpty(SschoolConfirmPass)) {
           Toast.makeText(getApplicationContext(), "الرجاء تعبئة جميع البيانات", Toast.LENGTH_LONG).show();
           return false;
       }
       if(!Patterns.EMAIL_ADDRESS.matcher(SschoolEmail).matches()){

           Toast.makeText(getApplicationContext(), "الرجاء ادخال البريد الالكتروني بشكل صحيح", Toast.LENGTH_LONG).show();
           return false; }

       if(!(SschoolID.length()==5)){
           Toast.makeText(getApplicationContext(), "رمز المدرسة يجب ان يحتوي على 5 ارقام فقط ", Toast.LENGTH_LONG).show();
           return false; }

       if(!(SschoolNumber.length()==10)){
           Toast.makeText(getApplicationContext(), "رقم التواصل يجب ان يحتوي على 10 ارقام فقط'", Toast.LENGTH_LONG).show();
           return false; }

       if(SsupervFName.matches(specialCharRegex) || SsupervFName.matches(NumberRegex)){
           Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
           return false;}
       if(SsupervSName.matches(specialCharRegex)|| SsupervSName.matches(NumberRegex)){
           Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
           return false;}
       if(SsupervThName.matches(specialCharRegex)|| SsupervThName.matches(NumberRegex)){
           Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
           return false;}

       if(!SschoolPass.equals(SschoolConfirmPass)){
           Toast.makeText(getApplicationContext(), "كلمة المرور غير متطابقة", Toast.LENGTH_LONG).show();
           return false;
       }
       if(SschoolPass.matches(specialCharRegex) || SschoolPass.length()<6 || !SschoolPass.matches(UpperCaseRegex) ||!SschoolPass.matches(NumberRegex)) {
           Toast.makeText(getApplicationContext(), "كلمة المرور يجب ان تكون ٦ ارقام او اكثر و يجب ان تحتوي على احرف كبيرة وصغيرة ", Toast.LENGTH_LONG).show();
           return false;
       }

        return true;
    }
    public void enterSchoolData(){
        user = firebaseAuth.getCurrentUser();

        mDatabase.child("Users").child(user.getUid()).setValue("Schools");
        mDatabase.child("Schools").child(user.getUid()).child("SchoolID").setValue(SschoolID);
        mDatabase.child("Schools").child(user.getUid()).child("SchoolName").setValue(SschoolName);
        mDatabase.child("Schools").child(user.getUid()).child("SuperVisorFName").setValue(SsupervFName);
        mDatabase.child("Schools").child(user.getUid()).child("SuperVisorSName").setValue(SsupervSName);
        mDatabase.child("Schools").child(user.getUid()).child("SuperVisorThName").setValue(SsupervThName);
        mDatabase.child("Schools").child(user.getUid()).child("schoolEmail").setValue(SschoolEmail);
        mDatabase.child("Schools").child(user.getUid()).child("SchoolPhone").setValue(SschoolNumber);

    }
}
