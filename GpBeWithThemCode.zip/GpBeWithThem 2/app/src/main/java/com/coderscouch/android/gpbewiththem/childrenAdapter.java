package com.coderscouch.android.gpbewiththem;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class childrenAdapter extends BaseAdapter {
    private Context mContext;
    private List<Children> childrenList;
    private String fullName;

    public childrenAdapter(Context mContext, List<Children> childrenList){
        this.mContext= mContext;
        this.childrenList = childrenList;
    }

    @Override
    public int getCount() {
        return childrenList.size();
    }

    @Override
    public Object getItem(int position) {
        return childrenList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        @SuppressLint("ViewHolder") View v = View.inflate(mContext, R.layout.list_children, null);
        TextView name = (TextView) v.findViewById(R.id.childName);
        TextView chipID = (TextView) v.findViewById(R.id.chipID);
        TextView schoolName = (TextView) v.findViewById(R.id.schoolName);
        TextView childClass = (TextView) v.findViewById(R.id.childClass);
        TextView childSex = (TextView) v.findViewById(R.id.childSex);
        Button editChild = (Button) v.findViewById(R.id.editChildInfoButton);

        fullName=childrenList.get(position).getChildFName()+" "+childrenList.get(position).getChildSName()+" "+childrenList.get(position).getChildThName();
        name.setText(fullName);
        childClass.setText(childrenList.get(position).getChildClass());
        schoolName.setText(childrenList.get(position).getSchoolName());
        chipID.setText(childrenList.get(position).getChipID());
        childSex.setText(childrenList.get(position).getChildSex());
        editChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value = childrenList.get(position).getChildID();
                Intent i = new Intent(mContext, modifyChildInformation.class);
                i.putExtra("childID", value);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(i);
            }
        });
        v.setTag(childrenList.get(position).getChildID());


        return v;
    }
}
