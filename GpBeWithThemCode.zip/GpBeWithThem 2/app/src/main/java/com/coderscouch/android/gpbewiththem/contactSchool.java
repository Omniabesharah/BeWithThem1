package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class contactSchool extends AppCompatActivity {
Button sendComplain,backButton;
EditText complainText;
        TextView phone, Email;
        String parentPhone , parentEmail , parentName,schoolID;
String ScomplainText;
DatabaseReference databaseReference;
FirebaseAuth firebaseAuth;
FirebaseUser user ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_school);
        final String childChip = getIntent().getStringExtra("childChip");

        complainText = (EditText)findViewById(R.id.complainText);
        sendComplain = (Button)findViewById(R.id.sendComplain);
        phone = (TextView)findViewById(R.id.phone);
        Email = (TextView)findViewById(R.id.email);
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        backButton = (Button)findViewById(R.id.backButton);


        try {

            databaseReference.child("Children").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Iterable<DataSnapshot>children = dataSnapshot.getChildren();
                    for(DataSnapshot child:children) {
                        if (child.child("ChildChipID").exists()) {
                            if (child.child("ChildChipID").getValue().toString().equals(childChip)) {

                                if (child.child("ChildSchool").exists()) {
                                    schoolID=child.child("ChildSchool").getValue().toString();
                                }
                            }
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                }
            });
            {

            }
        }catch (Exception e){

        }
        try {

            databaseReference.child("Schools").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Iterable<DataSnapshot>children = dataSnapshot.getChildren();
                    for(DataSnapshot child:children) {
                        if (child.child("SchoolID").exists()) {
                            if (child.child("SchoolID").getValue().toString().equals(schoolID)) {

                                phone.setText(child.child("SchoolPhone").getValue().toString());
                                Email.setText(child.child("schoolEmail").getValue().toString());
                            }
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                }
            });
            {

            }
        }catch (Exception e){

        }
        databaseReference.child("Parent").child(user.getUid()).addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {

                    parentEmail = map.get("ParentEmail");
                    parentPhone = map.get("ParentNumber");
                    parentName = map.get("ParentFName")+" "+map.get("ParentSName")+" "+map.get("ParentThName");

                } catch (Exception e) {

                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });
        sendComplain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add complains to the database
                ScomplainText = complainText.getText().toString();
               databaseReference= databaseReference.child("Complains").push();
                databaseReference.child("complainText").setValue(complainText.getText().toString());
                databaseReference.child("complainerID").setValue(user.getUid());
                databaseReference.child("complainerName").setValue((parentName));
                databaseReference.child("complainerNumber").setValue(parentPhone);
                databaseReference.child("complainerEmail").setValue(parentEmail);
                databaseReference.child("SchoolID").setValue(schoolID);
                Toast.makeText(getApplicationContext(),"تم تقديم الشكوى بنجاح",Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(),ParentsChildren.class));
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(),ParentsChildren.class));
                finish();
            }
        });
    }
}
