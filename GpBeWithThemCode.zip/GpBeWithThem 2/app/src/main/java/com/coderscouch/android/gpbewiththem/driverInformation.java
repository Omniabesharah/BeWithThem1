package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class driverInformation extends AppCompatActivity {
EditText driverFName , driverSName , driverThName  , driverPass , driverNumber;
TextView driverID, driverEmail;
DatabaseReference databaseReference;
Button editInformation , deleteDriver;
    private String sdriverEmail;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_information);
        String driverDbID = getIntent().getStringExtra("driverDbID");

        driverFName = (EditText) findViewById(R.id.driverFName);
        driverSName = ( EditText)findViewById(R.id.driverSName);
        driverThName = (EditText)findViewById(R.id.driverThName);
        driverID = (TextView)findViewById(R.id.driverID);
        driverPass = (EditText)findViewById(R.id.driverPass);
        driverNumber = (EditText)findViewById(R.id.driverPhone);
        driverEmail = (TextView)findViewById(R.id.driverEmail);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Driver").child(driverDbID);
        editInformation = (Button)findViewById(R.id.saveChanges);
        deleteDriver = (Button)findViewById(R.id.deleteDriverButton);
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(driverInformation.this, schoolMain.class);
                startActivity(myIntent);
            }
        });
    databaseReference.addValueEventListener(new ValueEventListener() {

        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

            try {
                driverFName.setText(map.get("DriverFName"));
                driverSName.setText(map.get("DriverSName"));
                driverThName.setText(map.get("DriverThName"));
                driverID.setText(map.get("DriverID"));
                driverNumber.setText(map.get("DriverNumber"));
                driverEmail.setText(map.get("DriverEmail"));

            } catch (Exception e) {

            }
        }


    @Override
    public void onCancelled(DatabaseError databaseError) {
        Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
    }
});
        editInformation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("DriverFName").setValue(driverFName.getText().toString());

                databaseReference.child("DriverSName").setValue(driverSName.getText().toString());

                databaseReference.child("DriverThName").setValue(driverThName.getText().toString());

                databaseReference.child("DriverNumber").setValue(driverNumber.getText().toString());

            }
        });
        deleteDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("approved").setValue("No");

                Toast.makeText(getApplicationContext(), "تم الحذف بنجاح", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(driverInformation.this, schoolMain.class);

                startActivity(intent);
                finish();
            }
        });



    }



}
