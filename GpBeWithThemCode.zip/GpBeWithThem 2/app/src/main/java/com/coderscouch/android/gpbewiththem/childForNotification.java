package com.coderscouch.android.gpbewiththem;
public class childForNotification {
    String  card , name ;

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
