package com.coderscouch.android.gpbewiththem;

import android.widget.EditText;

public class Drivers {

    String driverFName , driverSName, driverThName , driverNumber , driverEmail , driverPassword, driverPasswordConfirm,driverID , driverDBID;

    public String getDriverDBID() {
        return driverDBID;
    }

    public void setDriverDBID(String driverDBID) {
        this.driverDBID = driverDBID;
    }

    public String getDriverFName() {
        return driverFName;
    }

    public void setDriverFName(String driverFName) {
        this.driverFName = driverFName;
    }

    public String getDriverSName() {
        return driverSName;
    }

    public void setDriverSName(String driverSName) {
        this.driverSName = driverSName;
    }

    public String getDriverThName() {
        return driverThName;
    }

    public void setDriverThName(String driverThName) {
        this.driverThName = driverThName;
    }

    public String getDriverNumber() {
        return driverNumber;
    }

    public void setDriverNumber(String driverNumber) {
        this.driverNumber = driverNumber;
    }

    public String getDriverEmail() {
        return driverEmail;
    }

    public void setDriverEmail(String driverEmail) {
        this.driverEmail = driverEmail;
    }

    public String getDriverPassword() {
        return driverPassword;
    }

    public void setDriverPassword(String driverPassword) {
        this.driverPassword = driverPassword;
    }

    public String getDriverPasswordConfirm() {
        return driverPasswordConfirm;
    }

    public void setDriverPasswordConfirm(String driverPasswordConfirm) {
        this.driverPasswordConfirm = driverPasswordConfirm;
    }

    public String getDriverID() {
        return driverID;
    }

    public void setDriverID(String driverID) {
        this.driverID = driverID;
    }
}
