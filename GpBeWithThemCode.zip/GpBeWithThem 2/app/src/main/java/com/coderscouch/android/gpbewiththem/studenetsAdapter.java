package com.coderscouch.android.gpbewiththem;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class studenetsAdapter extends BaseAdapter {
    private Context mContext;
    private List<Children> childrenList;
    private String fullName;
    public studenetsAdapter(Context mContext, List<Children> childrenList){
        this.mContext= mContext;
        this.childrenList = childrenList;
    }

    @Override
    public int getCount() {
        return childrenList.size();
    }

    @Override
    public Object getItem(int position) {
        return childrenList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        @SuppressLint("ViewHolder") View v = View.inflate(mContext, R.layout.list_students, null);
        TextView name = (TextView) v.findViewById(R.id.childName);
        TextView chipID = (TextView) v.findViewById(R.id.chipID);
        TextView schoolName = (TextView) v.findViewById(R.id.schoolName);
        TextView childClass = (TextView) v.findViewById(R.id.childClass);
        TextView childSex = (TextView) v.findViewById(R.id.childSex);

        fullName=childrenList.get(position).getChildFName()+" "+childrenList.get(position).getChildSName()+" "+childrenList.get(position).getChildThName();
        name.setText(fullName);
        childClass.setText(childrenList.get(position).getChildClass());
        schoolName.setText(childrenList.get(position).getSchoolName());
        chipID.setText(childrenList.get(position).getChipID());
        childSex.setText(childrenList.get(position).getChildSex());

        v.setTag(childrenList.get(position).getChildID());


        return v;
    }
}
