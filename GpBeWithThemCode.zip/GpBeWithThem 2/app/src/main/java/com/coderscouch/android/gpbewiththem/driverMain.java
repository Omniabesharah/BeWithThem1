package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

public class driverMain extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private EditText driverName,schoolName ;
    private FirebaseUser user;
    FirebaseAuth firebaseAuth;
    private String schoolID;
    private String chipID,date;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String dateToday;
    private Button signOut;
    private TextView studentsNumber;
    private List<String> childrenList,checkinList;
    private boolean checking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_main);
firebaseAuth = FirebaseAuth.getInstance();
        childrenList = new ArrayList<>();
        checkinList = new ArrayList<>();
schoolName = (EditText)findViewById(R.id.schoolName);
        driverName = (EditText) findViewById(R.id.driverName);
        studentsNumber = (TextView)findViewById(R.id.studentsNumber);
        signOut = (Button)findViewById(R.id.signOutButton);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        user = FirebaseAuth.getInstance().getCurrentUser();
        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        dateToday = dateFormat.format(calendar.getTime());
        schoolName.setText(" ");

        databaseReference.child("Driver").child(user.getUid()).addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {

                    driverName.setText(map.get("DriverFName")+" "+map.get("DriverSName")+" "+map.get("DriverThName"));
                    databaseReference.child("Schools").child(map.get("SchoolID")).addValueEventListener(new ValueEventListener() {

                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                            try {
                                schoolName.setText(map.get("SchoolName"));
                                schoolID = map.get("SchoolID");

                             call(schoolID);
                            } catch (Exception e) {

                            }
                        }


                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
                        }
                    });

                } catch (Exception e) {

                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });

signOut.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        firebaseAuth.signOut();
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
        finish();
    }
});

    }

    private void call(final String schoolID) {

        try {
            databaseReference.child("check-in").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Iterable<DataSnapshot>children = dataSnapshot.getChildren();
                    for(DataSnapshot child:children){
                        if(child.child("card").exists()){
            chipID = child.child("card").getValue().toString();
            date = child.child("date").getValue().toString();
                            if (date.equals(dateToday)) {
              final String key = child.getKey();
              if(!checkinList.contains(key)){
                                databaseReference.child("Children").addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        Iterable<DataSnapshot> children = dataSnapshot.getChildren();
                                        for (DataSnapshot child : children) {
                                            if (child.child("ChildChipID").exists()) {

                                                if (child.child("ChildChipID").getValue().toString().equals(chipID)) {

                                                    if (child.child("ChildSchool").exists()) {
                                                        if (child.child("ChildSchool").getValue().toString().equals(schoolID)) {

                                                            if(!childrenList.contains(chipID)){
                                                               childrenList.add(chipID);
                                                                  checkinList.add(key);

                                                            }else{
                                                                childrenList.remove(chipID);
                                                                checkinList.add(key);
                                                            }
                                                        }
                                                    }

                                                }
                                            }
                                        }
                                        String size = "" + childrenList.size();
                                        studentsNumber.setText(size);
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                                    }
                                });}

                            }
                            }}}

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                }
            });

        }catch (Exception e){

        }
    }
    private void call2(final String chipID,final String schoolID){
        try {
            databaseReference.child("Children").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Iterable<DataSnapshot> children = dataSnapshot.getChildren();
                    for (DataSnapshot child : children) {
                        if (child.child("ChildChipID").exists()) {

                            if (child.child("ChildChipID").getValue().toString().equals(chipID)) {

                                if (child.child("ChildSchool").exists()) {
                                    if (child.child("ChildSchool").getValue().toString().equals(schoolID)) {

                                            if(!childrenList.contains(chipID)){
                                                childrenList.add(chipID);


                                            }else{
                                                childrenList.remove(chipID);

                                        }
                                    }
                                }

                            }
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                }
            });
            {

            }
        }catch (Exception e){

        }

    }

}
