package com.coderscouch.android.gpbewiththem;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ComplainsAdapter extends BaseAdapter {
    private Context mContext;
    private List<Complains>complainsList;
    private String name;

    public ComplainsAdapter(Context mContext , List<Complains> complainsList){
        this.mContext = mContext;
        this.complainsList = complainsList;
    }
    @Override
    public int getCount() {
        return complainsList.size();
    }

    @Override
    public Object getItem(int position) {
        return complainsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        @SuppressLint("ViewHolder") View v = View.inflate(mContext, R.layout.list_complains, null);
        TextView complainerName = (TextView) v.findViewById(R.id.parentName);
        TextView complainerEmail = (TextView) v.findViewById(R.id.complainerEmail);
        TextView complainerNumber = (TextView) v.findViewById(R.id.complainerPhone);
        TextView complainText = (TextView) v.findViewById(R.id.complainText);

       complainerName.setText(complainsList.get(position).getComplainerName());
        complainerEmail.setText(complainsList.get(position).getComplainerEmail());
        complainerNumber.setText(complainsList.get(position).getComplainerNumber());
        complainText.setText(complainsList.get(position).getComplainText());

        v.setTag(complainsList.get(position).getComplainerID());


        return v;
    }
}
