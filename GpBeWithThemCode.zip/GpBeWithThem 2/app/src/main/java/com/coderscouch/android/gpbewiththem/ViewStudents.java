package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ViewStudents extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private DatabaseReference reference;
    private FirebaseUser firebaseUser;
    private ListView studentsListView;
    private List<Children> studentsList;
    private Children childObj;
    private String schoolID;
    private studenetsAdapter adapter;
    private Button backButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_students);
        reference = FirebaseDatabase.getInstance().getReference();
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        studentsListView = (ListView) findViewById(R.id.studentsListView);
        studentsList = new ArrayList<>();
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(ViewStudents.this, schoolMain.class);
                startActivity(myIntent);
            }
        });
        reference.child("Schools").child(firebaseUser.getUid()).addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {
                    schoolID = map.get("SchoolID");
                } catch (Exception e) {

                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });

        try {
            reference.child("Children").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Iterable<DataSnapshot>children = dataSnapshot.getChildren();
                    for(DataSnapshot child:children){
                        if(child.child("ChildSchool").exists()){
                            if(child.child("ChildSchool").getValue().toString().equals(schoolID)) {
                                childObj = new Children();
                                childObj.setChildID(child.getKey());
                                if (child.child("ChildChipID").exists()) {
                                    childObj.setChipID(child.child("ChildChipID").getValue().toString());
                                }
                                if (child.child("ChildSchool").exists()) {
                                    childObj.setSchoolName(child.child("ChildSchool").getValue().toString());
                                }
                                if (child.child("ChildClass").exists()) {
                                    childObj.setChildClass(child.child("ChildClass").getValue().toString());
                                }
                                if (child.child("ChildSchool").exists()) {
                                    childObj.setSchoolName(child.child("ChildSchool").getValue().toString());
                                }
                                if (child.child("ChildSex").exists()) {
                                    childObj.setChildSex(child.child("ChildSex").getValue().toString());
                                }
                                if (child.child("ChildFName").exists()) {
                                    childObj.setChildFName(child.child("ChildFName").getValue().toString());
                                }
                                if (child.child("ChildSName").exists()) {
                                    childObj.setChildSName(child.child("ChildSName").getValue().toString());
                                }
                                if (child.child("ChildThName").exists()) {
                                    childObj.setChildThName(child.child("ChildThName").getValue().toString());
                                }
                                if (child.child("ChildAddress").exists()) {
                                    childObj.setChildAddress(child.child("ChildAddress").getValue().toString());
                                }
                                studentsList.add(childObj);
                                adapter = new studenetsAdapter(getApplicationContext(), studentsList);
                                studentsListView.setAdapter(adapter);
                            } }}//the end of for !!!!!........
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                }
            });
            {

            }
        }catch (Exception e){

        }





    }
}
