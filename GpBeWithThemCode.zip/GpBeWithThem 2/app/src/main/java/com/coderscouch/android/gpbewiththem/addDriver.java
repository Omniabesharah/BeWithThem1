package com.coderscouch.android.gpbewiththem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class addDriver extends AppCompatActivity {
Button addDriver;
FirebaseUser user;
     FirebaseUser schoolUser;
    EditText driverFName , driverSName, driverThName , driverNumber , driverEmail , driverPassword, driverPasswordConfirm,driverID ;
    String SdriverFName , SdriverSName, SdriverThName , SdriverNumber , SdriverEmail , SdriverPassword, SdriverPasswordConfirm,SdriverID ;
DatabaseReference databaseReference;
    FirebaseAuth firebaseAuth;
    private String schoolId;
    private String email;
    private String pass;
    private Button backButton;
    String specialCharRegex= ".*[@#!$%^&+=].*";
    String UpperCaseRegex= ".*[A-Z].*";
    String NumberRegex= ".*[0-9].*";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_driver);

        email = getIntent().getStringExtra("email");
        pass = getIntent().getStringExtra("pass");
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference= FirebaseDatabase.getInstance().getReference();
        user = firebaseAuth.getCurrentUser();
        schoolId = user.getUid();
        driverFName = (EditText)findViewById(R.id.driverFName);
        driverSName = (EditText)findViewById(R.id.driverSName);
        driverThName = (EditText)findViewById(R.id.driverThName);
        driverNumber = (EditText)findViewById(R.id.driverPhone);
        driverEmail = (EditText)findViewById(R.id.driverEmail);
        driverPassword = (EditText)findViewById(R.id.driverPass);
        driverPasswordConfirm = (EditText)findViewById(R.id.driverPassConfirm);
        driverID= (EditText)findViewById(R.id.driverID);
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(addDriver.this, schoolMain.class);
                startActivity(myIntent);
            }
        });
        addDriver  = (Button)findViewById(R.id.addDriverButton) ;

        addDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //calling the method for retrieving data from xml file
                getText();
                //calling the method for data validation
                if(checkTexts()) {

                    //if all data is valid then register the new user
                    registerNewUser();

                }
            }
        });
    }
    private void registerNewUser() {

        //register new user using email and password method
        firebaseAuth.createUserWithEmailAndPassword(SdriverEmail, SdriverPassword)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    //checking if register is completed
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            enterDriverData();
                            firebaseAuth.signOut();
                            Toast.makeText(getApplicationContext(), "تم التسجيل بنجاح", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(addDriver.this, MainActivity.class);
                            finish();
                            startActivity(intent);

                        }
                        else {
                            Toast.makeText(getApplicationContext(), "لا يمكنك التسجيل البريد الالكترواني موجود", Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }

    //return the text from the xml file to the variables in  java class

    public void getText(){
        SdriverFName = driverFName.getText().toString();
        SdriverSName = driverSName.getText().toString();
        SdriverPassword =driverPassword.getText().toString();
        SdriverPasswordConfirm =driverPasswordConfirm.getText().toString();
        SdriverEmail = driverEmail.getText().toString();
        SdriverThName=driverThName.getText().toString();
        SdriverNumber=driverNumber.getText().toString();
        SdriverID = driverID.getText().toString();
    }

    // validation of the text
    public Boolean checkTexts(){
        //data validation
        if (TextUtils.isEmpty(SdriverEmail)||TextUtils.isEmpty(SdriverNumber)|TextUtils.isEmpty(SdriverPasswordConfirm)||TextUtils.isEmpty(SdriverThName)||TextUtils.isEmpty(SdriverSName)||TextUtils.isEmpty(SdriverID)||TextUtils.isEmpty(SdriverPassword)||TextUtils.isEmpty(SdriverFName)) {
            Toast.makeText(getApplicationContext(), "الرجاء تعبئة جميع البيانات", Toast.LENGTH_LONG).show();
            return false;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(SdriverEmail).matches()){

            Toast.makeText(getApplicationContext(), "الرجاء ادخال البريد الالكتروني بشكل صحيح", Toast.LENGTH_LONG).show();
            return false; }
        if(!(SdriverID.length()==10)){
            Toast.makeText(getApplicationContext(), "رقم الهوية يجب ان يحتوي على 10 ارقام فقط ", Toast.LENGTH_LONG).show();
            return false; }

        if(SdriverPassword.matches(specialCharRegex) || SdriverPassword.length()<6 || !SdriverPassword.matches(UpperCaseRegex) ||!SdriverPassword.matches(NumberRegex)) {
            Toast.makeText(getApplicationContext(), "كلمة المرور يجب ان تكون ٦ ارقام او اكثر و يجب ان تحتوي على احرف كبيرة وصغيرة ", Toast.LENGTH_LONG).show();
            return false;
        }

        if(SdriverFName.matches(specialCharRegex) || SdriverFName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(SdriverSName.matches(specialCharRegex)|| SdriverSName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(SdriverThName.matches(specialCharRegex)|| SdriverThName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(!(SdriverNumber.length()==10)){
            Toast.makeText(getApplicationContext(), "رقم الجوال يجب ان يحتوي على 10 ارقام فقط'", Toast.LENGTH_LONG).show();
            return false; }

        if(!SdriverPassword.equals(SdriverPasswordConfirm)){
            Toast.makeText(getApplicationContext(), "كلمة المرور غير متطابقة", Toast.LENGTH_LONG).show();
            return false;
        }


        return true;
    }


    //entering the rest of the data after signing up the email and password in firebase
    public void enterDriverData(){
        user = firebaseAuth.getCurrentUser();

        // entering the driver data to the database after registering the driver email .
        databaseReference.child("Users").child(user.getUid()).setValue("Driver");
        databaseReference.child("Driver").child(user.getUid()).child("DriverID").setValue(SdriverID);
        databaseReference.child("Driver").child(user.getUid()).child("DriverEmail").setValue(SdriverEmail);
        databaseReference.child("Driver").child(user.getUid()).child("DriverFName").setValue(SdriverFName);
        databaseReference.child("Driver").child(user.getUid()).child("DriverSName").setValue(SdriverSName);
        databaseReference.child("Driver").child(user.getUid()).child("DriverThName").setValue(SdriverThName);
        databaseReference.child("Driver").child(user.getUid()).child("DriverNumber").setValue(SdriverNumber);
        //entering the saved school user id to the driver to connect them together
        databaseReference.child("Driver").child(user.getUid()).child("SchoolID").setValue(schoolId);
        databaseReference.child("Driver").child(user.getUid()).child("approved").setValue("YES");


    }

}
