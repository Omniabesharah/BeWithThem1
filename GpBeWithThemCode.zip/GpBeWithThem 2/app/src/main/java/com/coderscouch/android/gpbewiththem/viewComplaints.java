package com.coderscouch.android.gpbewiththem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class viewComplaints extends AppCompatActivity {
FirebaseAuth firebaseAuth;
FirebaseUser user ;
private ListView complainsListView;
private DatabaseReference reference;
private ComplainsAdapter adapter;
private List<Complains>complainsList;
private Complains complainObj;
    private String schoolID;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_complaints);

        reference= FirebaseDatabase.getInstance().getReference();
        complainsListView = (ListView)findViewById(R.id.complainsListView);
        complainsList = new ArrayList<>();
        user = FirebaseAuth.getInstance().getCurrentUser();
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(viewComplaints.this, schoolMain.class);
                startActivity(myIntent);
            }
        });

        reference.child("Schools").child(user.getUid()).addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {
                    schoolID=map.get("SchoolID");

                } catch (Exception e) {

                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });
        try{
        reference.child("Complains").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot>children = dataSnapshot.getChildren();
                for(DataSnapshot child:children){
                        complainObj = new Complains();
                        complainObj.setComplainerID(child.getKey());
                    if (child.child("SchoolID").exists()) {
                        if(child.child("SchoolID").getValue().toString().equals(schoolID)){
                            if (child.child("complainText").exists()) {
                                complainObj.setComplainText(child.child("complainText").getValue().toString());
                            }
                            if (child.child("complainerName").exists()) {
                                complainObj.setComplainerName(child.child("complainerName").getValue().toString());
                            }
                            if (child.child("complainerNumber").exists()) {
                                complainObj.setComplainerNumber(child.child("complainerNumber").getValue().toString());
                            }
                            if (child.child("complainerEmail").exists()) {
                                complainObj.setComplainerEmail(child.child("complainerEmail").getValue().toString());
                            }

                            complainsList.add(complainObj);
                            adapter = new ComplainsAdapter(getBaseContext(), complainsList);
                            complainsListView.setAdapter(adapter);
                        }
                         }

                     }//the end of for !!!!!........
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

            }
        });}
    catch (Exception e){

    }
    }
}
