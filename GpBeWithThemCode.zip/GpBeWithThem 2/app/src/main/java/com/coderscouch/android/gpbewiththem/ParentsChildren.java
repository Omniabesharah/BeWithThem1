package com.coderscouch.android.gpbewiththem;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ParentsChildren extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    private ListView childrenListView;
    private DatabaseReference reference;
    private childrenAdapter adapter;
    private List<Children> childrenList;
    private Children childObj;
    private Context context;
    private Button signOutButton, addChildButton, editProfileButton,complainButton , notificationButton;
    private Button homeButton;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parents_children);

        addChildButton = (Button)findViewById(R.id.addChildButton);
        editProfileButton = (Button)findViewById(R.id.editParentProfile);
        notificationButton = (Button)findViewById(R.id.notificationButton);
        signOutButton = (Button)findViewById(R.id.signOutButton);
        homeButton = (Button)findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ParentsChildren.class));

            }
        });

        addChildButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),addNewChild.class));

            }
        });
        editProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),parentsPersonalPage.class));
            }
        });


        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ParentsNotification.class));
            }
        });




        reference = FirebaseDatabase.getInstance().getReference();
       firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        childrenListView = (ListView) findViewById(R.id.childrenListView);
        childrenList = new ArrayList<>();
        try {
            reference = reference.child("Children");
reference.addValueEventListener(new ValueEventListener() {
    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
        Iterable<DataSnapshot>children = dataSnapshot.getChildren();
        childrenList.clear();
        for(DataSnapshot child:children){
            if(child.child("ChildParentID").exists()){
            if(child.child("ChildParentID").getValue().toString().equals(firebaseUser.getUid()))
           {
                childObj = new Children();
                childObj.setChildID(child.getKey());
                if (child.child("ChildChipID").exists()) {
                    childObj.setChipID(child.child("ChildChipID").getValue().toString());
                }
                if (child.child("ChildClass").exists()) {
                    childObj.setChildClass(child.child("ChildClass").getValue().toString());
                }
                if (child.child("ChildSchool").exists()) {
                    childObj.setSchoolName(child.child("ChildSchool").getValue().toString());
                }
                if (child.child("ChildSex").exists()) {
                    childObj.setChildSex(child.child("ChildSex").getValue().toString());
                }
                if (child.child("ChildFName").exists()) {
                    childObj.setChildFName(child.child("ChildFName").getValue().toString());
                }
                if (child.child("ChildSName").exists()) {
                    childObj.setChildSName(child.child("ChildSName").getValue().toString());
                }
                if (child.child("ChildThName").exists()) {
                    childObj.setChildThName(child.child("ChildThName").getValue().toString());
                }
                if (child.child("ChildAddress").exists()) {
                    childObj.setChildAddress(child.child("ChildAddress").getValue().toString());
                }
                childrenList.add(childObj);

            } }}
        adapter = new childrenAdapter(getBaseContext(), childrenList);
        childrenListView.setAdapter(adapter);
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {
        Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

    }
});
        }catch (Exception e){

        }
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOutMethod();
            }
        });
    }
    public void signOutMethod(){
        firebaseAuth.signOut();
        startActivity(new Intent(ParentsChildren.this, MainActivity.class));
        finish();
    }
    }
