package com.coderscouch.android.gpbewiththem;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

    public class driverAdapter extends BaseAdapter {
    private Context mContext;
    private List<Drivers> driversList;
    private String fullName;
    public driverAdapter(Context mContext, List<Drivers> driversList){
        this.mContext= mContext;
        this.driversList = driversList;
    }

        @Override
        public int getCount() {
            return driversList.size();
        }

        @Override
        public Object getItem(int position) {
            return driversList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

        //declaring the variables from the cml file
            @SuppressLint("ViewHolder") View v = View.inflate(mContext, R.layout.list_driver, null);
            TextView name = (TextView) v.findViewById(R.id.driverName);
            TextView email = (TextView) v.findViewById(R.id.driverEmail);
            TextView driverNumber = (TextView) v.findViewById(R.id.driverPhone);
            TextView driverID = (TextView) v.findViewById(R.id.driverID);
            Button editDriver = (Button) v.findViewById(R.id.editDriverButton);

            //assigning the data from database which is stored in the driverList to the xml file .
            fullName=driversList.get(position).getDriverFName()+" "+driversList.get(position).getDriverSName()+" "+driversList.get(position).getDriverThName();
            name.setText(fullName);
            email.setText(driversList.get(position).getDriverEmail());
            driverNumber.setText(driversList.get(position).getDriverNumber());
            driverID.setText(driversList.get(position).getDriverID());

            v.setTag(driversList.get(position).getDriverDBID());
        editDriver.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        String value = driversList.get(position).getDriverDBID();
        Intent i = new Intent(mContext, driverInformation.class);
        i.putExtra("driverDbID", value);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(i);
    }
});

            return v;
        }
    }
