package com.coderscouch.android.gpbewiththem;

public class Complains {
String complainText , complainerName , complainerEmail , complainerNumber, complainerID;

    public String getComplainText() {
        return complainText;
    }

    public void setComplainText(String complainText) {
        this.complainText = complainText;
    }

    public String getComplainerName() {
        return complainerName;
    }

    public void setComplainerName(String complainerName) {
        this.complainerName = complainerName;
    }

    public String getComplainerEmail() {
        return complainerEmail;
    }

    public void setComplainerEmail(String complainerEmail) {
        this.complainerEmail = complainerEmail;
    }

    public String getComplainerNumber() {
        return complainerNumber;
    }

    public void setComplainerNumber(String complainerNumber) {
        this.complainerNumber = complainerNumber;
    }

    public String getComplainerID() {
        return complainerID;
    }

    public void setComplainerID(String complainerID) {
        this.complainerID = complainerID;
    }
}
