package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class parentSignUp extends AppCompatActivity {
FirebaseAuth firebaseAuth ;
DatabaseReference mDatabase;
    EditText parentFName,parentSName,parentThName,parentNumber,parentID,parentEmail,parentPass,parentConfirmPass;
    String SparentFName,SparentSName,SparentThName,SparentNumber, SparentID,SparentEmail,SparentPass,SparentConfirmPass;
    Button parentSignUpButton ;
    FirebaseUser user;
    private Button backButton;
    String specialCharRegex= ".*[@#!$%^&+=].*";
    String UpperCaseRegex= ".*[A-Z].*";
    String NumberRegex= ".*[0-9].*";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_sign_up);
        //declaring firebase variables and assigning the database to them
        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        parentFName = (EditText)findViewById(R.id.parentFName);
        parentSName = (EditText)findViewById(R.id.parentSName);
        parentThName = (EditText)findViewById(R.id.parentThName);
        parentNumber = (EditText)findViewById(R.id.parentNumber);
        parentID = (EditText)findViewById(R.id.parentID);
        parentEmail = (EditText)findViewById(R.id.parentEmail);
        parentPass = (EditText)findViewById(R.id.parentPass);
        parentConfirmPass = (EditText)findViewById(R.id.parentConfirmPass);
        parentSignUpButton = (Button)findViewById(R.id.parentSignUp);
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(parentSignUp.this, MainActivity.class);
                startActivity(myIntent);
            }
        });
        parentSignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getText();
                    if(checkTexts()){
                        registerNewUser();
                    }
            }
        });
    }
    public void getText(){

        SparentFName = parentFName.getText().toString();
        SparentSName = parentSName.getText().toString();
        SparentThName = parentThName.getText().toString();
        SparentNumber = parentNumber.getText().toString();
        SparentID = parentID.getText().toString();
        SparentEmail = parentEmail.getText().toString();
        SparentPass = parentPass.getText().toString();
        SparentConfirmPass = parentConfirmPass.getText().toString();

    }
    public Boolean checkTexts(){
        //data validation

        if (TextUtils.isEmpty(SparentEmail)||TextUtils.isEmpty(SparentPass)||TextUtils.isEmpty(SparentID)||TextUtils.isEmpty(SparentConfirmPass)||TextUtils.isEmpty(SparentFName)||TextUtils.isEmpty(SparentSName)||TextUtils.isEmpty(SparentThName)||TextUtils.isEmpty(SparentNumber)) {
            Toast.makeText(getApplicationContext(), "الرجاء تعبئة جميع البيانات", Toast.LENGTH_LONG).show();
            return false; }
        if(!Patterns.EMAIL_ADDRESS.matcher(SparentEmail).matches()){

            Toast.makeText(getApplicationContext(), "الرجاء ادخال البريد الالكتروني بشكل صحيح", Toast.LENGTH_LONG).show();
            return false; }

        if(!(SparentID.length()==10)){
            Toast.makeText(getApplicationContext(), "رقم الهوية يجب ان يحتوي على 10 ارقام فقط ", Toast.LENGTH_LONG).show();
            return false; }
        if(!(SparentNumber.length()==10)){
            Toast.makeText(getApplicationContext(), "رقم التواصل يجب ان يحتوي على 10 ارقام فقط'", Toast.LENGTH_LONG).show();
            return false; }
        if(SparentFName.matches(specialCharRegex) || SparentFName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(SparentSName.matches(specialCharRegex)|| SparentSName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(SparentThName.matches(specialCharRegex)|| SparentThName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(!SparentPass.equals(SparentConfirmPass)){
            Toast.makeText(getApplicationContext(), "كلمة المرور غير متطابقة", Toast.LENGTH_LONG).show();
            return false;
        }
        if(SparentPass.matches(specialCharRegex) || SparentPass.length()<6 || !SparentPass.matches(UpperCaseRegex) ||!SparentPass.matches(NumberRegex)) {
            Toast.makeText(getApplicationContext(), "كلمة المرور يجب ان تكون ٦ ارقام او اكثر و يجب ان تحتوي على احرف كبيرة وصغيرة ", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    private void registerNewUser() {
        //register new user using email and password method
        firebaseAuth.createUserWithEmailAndPassword(SparentEmail, SparentPass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    //checking if register is completed
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //if email and password are successfully registered then call the method that enters the rest of the data to the database

                            enterParentData();
                            Toast.makeText(getApplicationContext(), "تم التسجيل بنجاح", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(parentSignUp.this, MainActivity.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "لا يمكنك التسجيل البريد الالكترواني موجود", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(parentSignUp.this, parentSignUp.class);
                            startActivity(intent);
                        }
                    }
                });
    }
    public void enterParentData(){
        // entering parents data to the database after rigestering the parents email .
        user= firebaseAuth.getCurrentUser();
        mDatabase.child("Users").child(user.getUid()).setValue("Parent");
        mDatabase.child("Parent").child(user.getUid()).child("ParentID").setValue(SparentID);
        mDatabase.child("Parent").child(user.getUid()).child("ParentFName").setValue(SparentFName);
        mDatabase.child("Parent").child(user.getUid()).child("ParentSName").setValue(SparentSName);
        mDatabase.child("Parent").child(user.getUid()).child("ParentThName").setValue(SparentThName);
        mDatabase.child("Parent").child(user.getUid()).child("ParentNumber").setValue(SparentNumber);
        mDatabase.child("Parent").child(user.getUid()).child("ParentEmail").setValue(SparentEmail);

    }
}
