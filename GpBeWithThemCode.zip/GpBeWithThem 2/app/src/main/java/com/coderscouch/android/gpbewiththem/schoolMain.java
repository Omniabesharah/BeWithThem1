package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class schoolMain extends AppCompatActivity {
    Button addDriver, viewStudents, signout,profile,notification , home;
    FirebaseDatabase firebaseDatabase;
    FirebaseAuth firebaseAuth;
    DatabaseReference reference;
    private driverAdapter adapter;
    private List<Drivers> driversList;
    private ListView driversListView;
    private Drivers driverObj;
    private String schoolID;
    private FirebaseUser firebaseUser;
String email , pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        //set the content to the school main XML file
        setContentView(R.layout.activity_school_main);

        reference = FirebaseDatabase.getInstance().getReference();
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        //assigning buttons to the xml file buttons
        addDriver = (Button) findViewById(R.id.addDriverButton);
        viewStudents = (Button) findViewById(R.id.studentsSignedButton);
        signout = (Button) findViewById(R.id.signOutButton);
        profile = (Button) findViewById(R.id.editSchoolProfile);
        notification = (Button)findViewById(R.id.notificationButton);
        home= (Button)findViewById(R.id.homeButton);
        driversListView = (ListView) findViewById(R.id.driversListView);
        driversList = new ArrayList<>();


        try {

            //find the Driver lists from database
            reference = reference.child("Driver");
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Iterable<DataSnapshot> children = dataSnapshot.getChildren();

                    //when clicking on addDriver button , go to the add driver activity
                    addDriver.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(schoolMain.this, addDriver.class);
                            intent.putExtra("email", email);
                            intent.putExtra("pass", pass);
                            finish();
                            startActivity(intent);

                        }
                    });

                    //when clicking on view students button , go to the view students activity
                    viewStudents.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(schoolMain.this, ViewStudents.class));
                        }
                    });
                    profile.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(schoolMain.this, modifySchoolInformation.class));
                        }
                    });
                    notification.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(schoolMain.this, viewComplaints.class));
                        }
                    });
                    home.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(schoolMain.this, schoolMain.class));
                        }
                    });

                    //when clicking on signOut button , go to thesognOut activity

                    signout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                              signOutMethod();
                        }
                    });



                    //search for drivers based on the given school id
                    for (DataSnapshot child : children) {
                        if(child.child("SchoolID").exists()){

                            if (child.child("SchoolID").getValue().toString().equals(firebaseUser.getUid())) {
                                if (child.child("approved").getValue().toString().equals("YES")) {
                            //making a new driver object + assigning the variables from the data in the databse
                            driverObj = new Drivers();
                            driverObj.setDriverDBID(child.getKey());
                            if (child.child("DriverID").exists()) {
                                driverObj.setDriverID(child.child("DriverID").getValue().toString());
                            }
                            if (child.child("DriverEmail").exists()) {
                                driverObj.setDriverEmail(child.child("DriverEmail").getValue().toString());
                            }
                            if (child.child("DriverFName").exists()) {
                                driverObj.setDriverFName(child.child("DriverFName").getValue().toString());
                            }
                            if (child.child("DriverSName").exists()) {
                                driverObj.setDriverSName(child.child("DriverSName").getValue().toString());
                            }
                            if (child.child("DriverThName").exists()) {
                                driverObj.setDriverThName(child.child("DriverThName").getValue().toString());
                            }
                            if (child.child("DriverNumber").exists()) {
                                driverObj.setDriverNumber(child.child("DriverNumber").getValue().toString());
                            }

                            driversList.add(driverObj);
                            adapter = new driverAdapter(getBaseContext(), driversList);
                            driversListView.setAdapter(adapter);
                        }}
                    } }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                }
            });
            {

            }
        } catch (Exception e) {


        }

    }
    public void signOutMethod(){
        firebaseAuth.signOut();
        startActivity(new Intent(schoolMain.this, MainActivity.class));
        finish();
    }
}