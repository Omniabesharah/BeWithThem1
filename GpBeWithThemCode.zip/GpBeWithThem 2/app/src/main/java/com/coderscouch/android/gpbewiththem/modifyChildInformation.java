package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class modifyChildInformation extends AppCompatActivity {
Button saveModification , deleteChild;
EditText childFName , childSName , childThName , childAddress, childSex, childSchool , childClass,chipID;
    private DatabaseReference databaseReference;
    private String childID;
    private Button backButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_child_information);
        childID = getIntent().getStringExtra("childID");

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Children").child(childID);


        chipID = (EditText)findViewById(R.id.chipID);
        childFName = (EditText)findViewById(R.id.childFName);
        childSName = (EditText)findViewById(R.id.childSName);
        childThName = (EditText)findViewById(R.id.childThName);
        childAddress = (EditText)findViewById(R.id.childAddress);
        childSex = (EditText)findViewById(R.id.childSex);
        childSchool = (EditText)findViewById(R.id.childSchoolName);
        childClass = (EditText)findViewById(R.id.childClass);
        saveModification = ( Button)findViewById(R.id.saveModification);
        deleteChild = (Button)findViewById(R.id.deleteChildButton);
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getApplicationContext(), ParentsChildren.class);
                startActivity(myIntent);
            }
        });
        databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {
                    chipID.setText(map.get("ChildChipID"));
                    childFName.setText(map.get("ChildFName"));
                    childSName.setText(map.get("ChildSName"));
                    childThName.setText(map.get("ChildThName"));
                    childAddress.setText(map.get("ChildAddress"));
                    childSchool.setText(map.get("ChildSchool"));
                    childClass.setText(map.get("ChildClass"));
                    childSex.setText(map.get("ChildSex"));
                } catch (Exception e) {

                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });

        saveModification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("ChildChipID").setValue(chipID.getText().toString());
                databaseReference.child("ChildFName").setValue(childFName.getText().toString());
                databaseReference.child("ChildSName").setValue(childSName.getText().toString());
                databaseReference.child("ChildThName").setValue(childThName.getText().toString());
                databaseReference.child("ChildAddress").setValue(childAddress.getText().toString());
                databaseReference.child("ChildSex").setValue(childSex.getText().toString());
                databaseReference.child("ChildSchool").setValue(childSchool.getText().toString());
                databaseReference.child("ChildClass").setValue(childClass.getText().toString());
                Toast.makeText(getApplicationContext(),"تم تعديل معلومات الطفل بنجاح",Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(),ParentsChildren.class));
                finish();

            }
        });

        deleteChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.removeValue();
                Toast.makeText(getApplicationContext(),"تم حذف الطفل بنجاح",Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(),ParentsChildren.class));
                finish();

            }
        });
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ParentsChildren.class));
                finish();
            }
        });
    }


}
