package com.coderscouch.android.gpbewiththem;

import android.os.Build;

public class Children {


    protected String childFName;

    public String getChildAddress() {
        return ChildAddress;
    }

    public void setChildAddress(String childAddress) {
        ChildAddress = childAddress;
    }

    protected String ChildAddress;
    protected String chipID;
    protected String schoolName;
    protected String childClass;
    protected String childID;
    protected String childSex;
    protected String childSName;
    protected String childThName;

    public String getChildFName() {
        return childFName;
    }

    public void setChildFName(String childFName) {
        this.childFName = childFName;
    }

    public String getChipID() {
        return chipID;
    }

    public void setChipID(String chipID) {
        this.chipID = chipID;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getChildClass() {
        return childClass;
    }

    public void setChildClass(String childClass) {
        this.childClass = childClass;
    }

    public String getChildID() {
        return childID;
    }

    public void setChildID(String childID) {
        this.childID = childID;
    }

    public String getChildSex() {
        return childSex;
    }

    public void setChildSex(String childSex) {
        this.childSex = childSex;
    }

    public String getChildSName() {
        return childSName;
    }

    public void setChildSName(String childSName) {
        this.childSName = childSName;
    }

    public String getChildThName() {
        return childThName;
    }

    public void setChildThName(String childThName) {
        this.childThName = childThName;
    }


    public Children() {

    }
}

