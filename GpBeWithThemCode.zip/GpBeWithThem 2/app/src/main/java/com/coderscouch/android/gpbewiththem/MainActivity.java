package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class MainActivity extends AppCompatActivity {
TextView signUp;
FirebaseAuth firebaseAuth;
DatabaseReference databaseReference;
Button signInButton;
TextView forgotPassword;
EditText email,pass;
String Semail , Spass;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //assigning signUp text to the xml file text.
        signUp = (TextView) findViewById(R.id.signUp);
        email = (EditText)findViewById(R.id.email);
        pass = (EditText)findViewById(R.id.passEditText);
        signInButton = (Button)findViewById(R.id.signInButton);
        forgotPassword = (TextView)findViewById(R.id.forgotPass);


forgotPassword= (TextView)findViewById(R.id.forgotPass);

    forgotPassword.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent myIntent = new Intent(MainActivity.this ,forgotPassword.class);
            startActivity(myIntent);
        }
    });

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();


        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, signUpMain.class);
                startActivity(myIntent);
            }
        });

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //School();
                Semail = email.getText().toString();
                Spass = pass.getText().toString();
                signInAction();
            }
        });
    }

    public void signInAction() {


            try {
                firebaseAuth.signInWithEmailAndPassword(Semail, Spass)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull final Task<AuthResult> task) {
                                //if the task is successfull
                                if (task.isSuccessful()) {
                            user=firebaseAuth.getCurrentUser();
                                    //start the profile activity

                                    databaseReference.child("Users").child(user.getUid()).addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            try {
                                               String type = dataSnapshot.getValue().toString();

                                                if (type.equals("Schools")) {
                                                    School();
                                                }
                                                if (type.equals("Parent")) {
                                                    Parent();
                                                }
                                                if (type.equals("Driver")) {
                                                    driver();
                                                }
                                                finish();
                                            } catch (Exception e) {
                                                Toast.makeText(MainActivity.this, " خطا في تسجيل الدخول", Toast.LENGTH_LONG).show();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {
                                            Toast.makeText(MainActivity.this, task.getException().toString(), Toast.LENGTH_LONG).show();

                                        }
                                    });
                                } else {
                                    Toast.makeText(MainActivity.this, " خطا في تسجيل الدخول أرجو ادخال المعلومات بشكل صحيح", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }catch (Exception e){
                Toast.makeText(MainActivity.this, " خطا في تسجيل الدخول", Toast.LENGTH_LONG).show();
            }

    }
    private void Parent() {

        Intent intent = new Intent(getApplicationContext(), ParentsChildren.class);
        startActivity(intent);
        finish();
    }

    private void School() {

        Intent intent = new Intent(getApplicationContext(), schoolMain.class);
        intent.putExtra("email", email.getText().toString());
        intent.putExtra("pass", pass.getText().toString());
        startActivity(intent);
        finish();
    }
    private void driver() {
        databaseReference.child("Driver").child(user.getUid()).addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {
                    if(map.get("approved").equals("YES")){
                        startActivity(new Intent(getApplicationContext(), driverMain.class));
                        finish();
                    }else{
                        Toast.makeText(getApplicationContext(), "السائق غير مصرح له بالدخول", Toast.LENGTH_SHORT).show();

                    }

                } catch (Exception e) {

                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
