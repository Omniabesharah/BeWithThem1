package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class modifySchoolInformation extends AppCompatActivity {
    EditText schoolName , schoolID,supervisorFName,supervisorSName,supervisorThName,schoolEmail,schoolNumber,schoolPass;
    Button saveChanges ;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_school_information);
           firebaseAuth = FirebaseAuth.getInstance();
           user = firebaseAuth.getCurrentUser();
           databaseReference = FirebaseDatabase.getInstance().getReference().child("Schools").child(user.getUid());

        schoolName = (EditText)findViewById(R.id.schoolName);
        schoolID = (EditText)findViewById(R.id.schoolID);
        supervisorFName = (EditText)findViewById(R.id.supervisorFName);
        supervisorSName=(EditText)findViewById(R.id.supervisorSName);
        supervisorThName=(EditText)findViewById(R.id.supervisorThName);
        schoolEmail = (EditText)findViewById(R.id.schoolEmail);
        schoolPass = (EditText)findViewById(R.id.schoolPass);
        schoolNumber = (EditText)findViewById(R.id.schoolNumber);

        saveChanges = (Button)findViewById(R.id.saveChanges);
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(modifySchoolInformation.this, schoolMain.class);
                startActivity(myIntent);
            }
        });

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {
                    schoolName.setText(map.get("SchoolName"));
                    schoolID.setText(map.get("SchoolID"));
                    supervisorFName.setText(map.get("SuperVisorFName"));
                    supervisorSName.setText(map.get("SuperVisorSName"));
                    supervisorThName.setText(map.get("SuperVisorThName"));
                    schoolEmail.setText(map.get("schoolEmail"));
                    schoolNumber.setText(map.get("SchoolPhone"));
                }catch (Exception e){

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });

        saveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            databaseReference.child("SchoolName").setValue(schoolName);
                databaseReference.child("SchoolID").setValue(schoolID);
                databaseReference.child("SuperVisorFName").setValue(supervisorFName);
                databaseReference.child("SuperVisorSName").setValue(supervisorSName);
                databaseReference.child("SuperVisorThName").setValue(supervisorThName);
                databaseReference.child("schoolEmail").setValue(schoolEmail);
                databaseReference.child("SchoolPhone").setValue(schoolNumber);
                Toast.makeText(getApplicationContext(),"تم تعديل معلومات المدرسة بنجاح",Toast.LENGTH_LONG).show();

                if(!schoolPass.getText().toString().isEmpty()){
                user.updatePassword(schoolPass.getText().toString());}

            }
        });

    }
}
