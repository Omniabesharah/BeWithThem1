package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class parentsPersonalPage extends AppCompatActivity {
private FirebaseAuth firebaseAuth;
private DatabaseReference databaseReference;
private FirebaseUser user ;
EditText  parentFName , parentSName , parentThName , parentPass,parentNumber;
TextView parentEmail,parentID;
String SparentID , SparentFName,SparentSName,SparentThName,SparentEmail,SparentPass,SparentNumber ;
Button saveChanges , deleteAccount;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parents_personal_page);
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Parent").child(user.getUid());


        parentID = (TextView) findViewById(R.id.parentID);
        parentFName = (EditText) findViewById(R.id.parentFName);
        parentSName = (EditText) findViewById(R.id.parentSName);
        parentThName=(EditText) findViewById(R.id.parentThName);
        parentEmail = (TextView) findViewById(R.id.parentEmail);
        parentPass = (EditText) findViewById(R.id.parentPass);
        parentNumber = (EditText) findViewById(R.id.parentNumber);

        saveChanges = (Button)findViewById(R.id.saveChanges);
        deleteAccount=(Button)findViewById(R.id.deleteParentButton);
        parentEmail.setText(user.getEmail());
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(parentsPersonalPage.this, ParentsChildren.class);
                startActivity(myIntent);
            }
        });



        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> map = (Map<String, String>) dataSnapshot.getValue();

                try {
                    parentID.setText(map.get("ParentID"));
                    parentFName.setText(map.get("ParentFName"));
                    parentSName.setText(map.get("ParentSName"));
                    parentThName.setText(map.get("ParentThName"));
                    parentNumber.setText(map.get("ParentNumber"));
                }catch (Exception e){

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Failed to load.", Toast.LENGTH_SHORT).show();
            }
        });


        //when saving the changes .
        saveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("ParentFName").setValue(parentFName.getText().toString());
                databaseReference.child("ParentSName").setValue(parentSName.getText().toString());
                databaseReference.child("ParentThName").setValue(parentThName.getText().toString());
                databaseReference.child("ParentNumber").setValue(parentNumber.getText().toString());
                if(!parentPass.getText().toString().isEmpty()){
                    user.updatePassword(parentPass.getText().toString());
                    startActivity(new Intent(parentsPersonalPage.this,ParentsChildren.class));
                }


            }
        });
        deleteAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!parentEmail.getText().toString().isEmpty()){
                    if(!parentPass.getText().toString().isEmpty()){
                        databaseReference.removeValue();

                        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();



                        AuthCredential credential = EmailAuthProvider
                                .getCredential(parentEmail.getText().toString(), parentPass.getText().toString());

                        // Prompt the user to re-provide their sign-in credentials
                        user.reauthenticate(credential)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        user.delete()
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            Toast.makeText(getApplicationContext(),"تم حذف الحساب بنجاح",Toast.LENGTH_LONG).show();
                                                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                                                        }
                                                    }
                                                });

                                    }
                                });
                    }else{
                        Toast.makeText(getApplicationContext(),"الرجاء ادخال كلمة المرور لحذف الحساب",Toast.LENGTH_LONG).show();

                    }
                }else{
                    Toast.makeText(getApplicationContext(),"الرجاء ادخال البريد الالكتروني لحذف الحساب",Toast.LENGTH_LONG).show();

                }


            }
        });


    }
}
