package com.coderscouch.android.gpbewiththem;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class notificationAdapter extends BaseAdapter {

    private Context mContext;
    private List<Notification> notificationList;
    private String fullName;

    public notificationAdapter(Context mContext, List<Notification> notificationList){
        this.mContext= mContext;
        this.notificationList = notificationList;
    }

    @Override
    public int getCount() {
        return notificationList.size();
    }

    @Override
    public Object getItem(int position) {
        return notificationList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        @SuppressLint("ViewHolder") View v = View.inflate(mContext, R.layout.list_notification, null);
        TextView name = (TextView) v.findViewById(R.id.childName);
        TextView chipID = (TextView) v.findViewById(R.id.chipID);
        TextView date = (TextView) v.findViewById(R.id.date);
        TextView time = (TextView) v.findViewById(R.id.time);
        TextView notificationText = (TextView) v.findViewById(R.id.notificationText);
        Button complain = (Button) v.findViewById(R.id.contactSchool);

        fullName=notificationList.get(position).getChildName();
        name.setText(fullName);
        date.setText(notificationList.get(position).getDate());
        time.setText(notificationList.get(position).getTime());
        chipID.setText(notificationList.get(position).getChipID());
        notificationText.setText(notificationList.get(position).getMessage());
        complain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value = notificationList.get(position).getChipID();
                Intent i = new Intent(mContext, contactSchool.class);
                i.putExtra("childChip", value);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(i);
            }
        });


        return v;
    }
}
