package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class addNewChild extends AppCompatActivity {
EditText  childChipID , childAddress , childSex , childClass , childFName , childSName , childThName ,childSchool;
String  SchildChipID , SchildAddress , SchildSex, SchildClass , SchildFName , SchildSName , SchildThName,SchildSchool ;
Button addNewChild ,backButton ;
DatabaseReference databaseReference;
FirebaseDatabase firebaseDatabase;
FirebaseAuth firebaseAuth;
FirebaseUser user ;
    String specialCharRegex= ".*[@#!$%^&+=].*";
    String NumberRegex= ".*[0-9].*";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_child);

        //assigning the xml variables to the variables in here
        childFName = (EditText)findViewById(R.id.childFName);
        childSName = (EditText)findViewById(R.id.childSName);
        childThName = (EditText)findViewById(R.id.childThName);
        childClass = ( EditText)findViewById(R.id.childClass);
        childSex=(EditText) findViewById(R.id.childSex);
        childChipID = (EditText)findViewById(R.id.chipID);
        childAddress = (EditText)findViewById(R.id.childAddress);
        addNewChild = (Button)findViewById(R.id.addChildButton);
        childSchool= (EditText)findViewById(R.id.childSchoolID) ;
        backButton = (Button)findViewById(R.id.backButton);

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();

        user = firebaseAuth.getCurrentUser();

        addNewChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getText();
               if(checkTexts()){
                   enterData();
               }

            }
        });
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ParentsChildren.class));
                finish();
            }
        });



    }

    public void getText(){

        SchildFName = childFName.getText().toString();
        SchildSName = childSName.getText().toString();
        SchildThName = childThName.getText().toString();
        SchildClass = childClass.getText().toString();
        SchildSex = childSex.getText().toString();
        SchildChipID = childChipID.getText().toString();
        SchildAddress = childAddress.getText().toString();
        SchildSchool = childSchool.getText().toString();
    }

    //validation the texts
    public boolean checkTexts(){
        if (TextUtils.isEmpty(SchildChipID)||(TextUtils.isEmpty(SchildSchool)||(TextUtils.isEmpty(SchildSex)||TextUtils.isEmpty(SchildClass))||TextUtils.isEmpty(SchildAddress))||(TextUtils.isEmpty(SchildFName))||(TextUtils.isEmpty(SchildSName))||(TextUtils.isEmpty(SchildThName))) {
            Toast.makeText(getApplicationContext(), "الرجاء تعبئة جميع البيانات", Toast.LENGTH_LONG).show();
            return false;
        }

        if(SchildSName.matches(specialCharRegex) || SchildSName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(SchildFName.matches(specialCharRegex)|| SchildFName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(SchildThName.matches(specialCharRegex)|| SchildThName.matches(NumberRegex)){
            Toast.makeText(getApplicationContext(), "يجب ان لا يحتوي الاسم على رموز او ارقام", Toast.LENGTH_LONG).show();
            return false;}
        if(!(SchildSchool.length()==5)){
            Toast.makeText(getApplicationContext(), "مز المدرسة يجب ان يحتوي على 5 ارقام فقط ", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }


    //entering the data to the firebase database
    public void enterData(){
        databaseReference=databaseReference.child("Children").push();
        databaseReference.child("ChildChipID").setValue(SchildChipID);
        databaseReference.child("ChildFName").setValue(SchildFName);
        databaseReference.child("ChildSName").setValue(SchildSName);
        databaseReference.child("ChildThName").setValue(SchildThName);
        databaseReference.child("ChildParentID").setValue(user.getUid());
        databaseReference.child("ChildAddress").setValue(SchildAddress);
        databaseReference.child("ChildSex").setValue(SchildSex);
        databaseReference.child("ChildSchool").setValue(SchildSchool);
        databaseReference.child("ChildClass").setValue(SchildClass);
        Toast.makeText(getApplicationContext(),"تم اضافة الطفل بنجاح",Toast.LENGTH_LONG).show();
        startActivity(new Intent(getApplicationContext(),ParentsChildren.class));
        finish();

    }
}
