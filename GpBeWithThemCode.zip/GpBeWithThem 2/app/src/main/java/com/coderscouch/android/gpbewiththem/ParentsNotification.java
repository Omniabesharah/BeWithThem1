package com.coderscouch.android.gpbewiththem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
//this is another version
public class ParentsNotification extends AppCompatActivity {

    FirebaseUser user ;
    private ListView notificationListView;
    private DatabaseReference reference;
    private notificationAdapter adapter;
    private List<Notification> notificationList;

    private Notification notificationObj;
    private Notification notificationObj2;
    List<String> childID,childName;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parents_notification);
        user= FirebaseAuth.getInstance().getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference();
        notificationListView = (ListView)findViewById(R.id.notificationListView);
        notificationList = new ArrayList<>();
        childID = new ArrayList<>() ;
        childName = new ArrayList<>() ;
        final Hashtable<String, Notification> capitals = new Hashtable<String, Notification>();
        backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(ParentsNotification.this, ParentsChildren.class);
                startActivity(myIntent);
            }
        });



        try{
            reference.child("check-in").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for(DataSnapshot snapshot:dataSnapshot.getChildren())
                    {
                        notificationObj = new Notification();
                        notificationObj.setChipID(snapshot.child("card").getValue().toString());
                        notificationObj.setDate( snapshot.child("date").getValue().toString());
                        notificationObj.setTime( snapshot.child("time").getValue().toString());
                        if(snapshot.child("State").getValue().toString().matches("1"))
                        {
                            notificationObj.setMessage("طفلك دخل الى الباص");
                        }
                        else
                        {
                            notificationObj.setMessage("طفلك خرج من الباص");
                        }

                        final String card = snapshot.getKey();
                        capitals.put(card,notificationObj);


                    }


                    // get keys() from Hashtable and iterate
                    Enumeration<String> enumeration = capitals.keys();

                    while(enumeration.hasMoreElements()) {
                        final String key = enumeration.nextElement();

                        final String card = capitals.get(key).chipID;
                      reference.child("Children").addValueEventListener(new ValueEventListener() {
                            @Override

                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                for(DataSnapshot snapshot:dataSnapshot.getChildren()) {
                                    if (snapshot.child("ChildChipID").exists()) {
                                        if (snapshot.child("ChildChipID").getValue().toString().equals(card)) {
                                            if (snapshot.child("ChildParentID").getValue().toString().equals(user.getUid())) {
                                                notificationObj2 = new Notification();
                                                notificationObj2.setChipID(capitals.get(key).chipID);
                                                notificationObj2.setChildName(snapshot.child("ChildFName").getValue().toString() + " " + snapshot.child("ChildSName").getValue().toString() + " " + snapshot.child("ChildThName").getValue().toString());
                                                notificationObj2.setDate(capitals.get(key).date);
                                                notificationObj2.setTime(capitals.get(key).time);
                                                notificationObj2.setMessage(capitals.get(key).message);
                                                notificationList.add(notificationObj2);
                                            }
                                        }

                                    }
                                }

                                    adapter = new notificationAdapter(getBaseContext(), notificationList);
                                    notificationListView.setAdapter(adapter);

                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                            }
                        });
                    }
                    }



                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getBaseContext(), "Failed to load.", Toast.LENGTH_SHORT).show();

                }

            });}
        catch (Exception e){

        }






    }

    private String getMessage(String time) {


        return "";
    }

}
